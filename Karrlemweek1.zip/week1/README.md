Week 1 in class exercise:
- Download files from this repo.
- Using the JavaScript  file, create a design that combines at least 5 of each of the following elements:
	- Images
	- Colors
	- Font styles
- Do not edit the HTML file.
- Create a .zip archive and email them to me.